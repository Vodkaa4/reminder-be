<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\reminder-be\resources\views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>