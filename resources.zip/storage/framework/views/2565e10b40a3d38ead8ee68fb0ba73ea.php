<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\laragon\www\reminder-be\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>