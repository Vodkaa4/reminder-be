<?php $__env->startComponent('mail::message'); ?>
# Pengingat <?php echo new \Illuminate\Support\EncodedHtmlString(strtoupper($entity)); ?> H-<?php echo new \Illuminate\Support\EncodedHtmlString($daysBefore); ?>


**<?php echo new \Illuminate\Support\EncodedHtmlString($title); ?>**  
Jatuh tempo: **<?php echo new \Illuminate\Support\EncodedHtmlString(\Carbon\Carbon::parse($targetDate)->format('d M Y')); ?>**

<?php $__env->startComponent('mail::button', ['url' => config('app.url').'/admin']); ?>
Buka Dashboard
<?php echo $__env->renderComponent(); ?>

Terima kasih,  
<?php echo new \Illuminate\Support\EncodedHtmlString(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\reminder-be\resources\views/emails/reminder.blade.php ENDPATH**/ ?>